const axios = require('axios')
const cheerio = require('cheerio')

class Harpi {
  constructor() {
    this.baseUrl = 'https://harpi.in'
    this.headers = {
      'User-Agent': 'Mozilla/5.0',
      'Referer': this.baseUrl
    }
  }

  async request(url) {
    return await axios.get(url, { headers: this.headers })
  }

  async getHomePageSections() {
    const res = await this.request(this.baseUrl)
    const $ = cheerio.load(res.data)

    const map = new Map()

    $('a').each((i, el) => {
      const link = $(el).attr('href')
      const title = $(el).text().trim()
      const img = $(el).find('img').attr('src')

      if (link && link.includes('/comic/')) {
        map.set(link, {
          id: this.baseUrl + link,
          title: title || '제목 없음',
          image: img ? this.baseUrl + img : '',
          subtitle: ''
        })
      }
    })

    return [{
      id: 'latest',
      title: '🔥 최신 작품',
      items: Array.from(map.values()).slice(0, 40)
    }]
  }

  async getSearchResults(query) {
    const url = `${this.baseUrl}/search?q=${encodeURIComponent(query)}`
    const res = await this.request(url)
    const $ = cheerio.load(res.data)

    const results = []
    const seen = new Set()

    $('a').each((i, el) => {
      const link = $(el).attr('href')
      const title = $(el).text().trim()
      const img = $(el).find('img').attr('src')

      if (link && link.includes('/comic/') && !seen.has(link)) {
        seen.add(link)

        results.push({
          id: this.baseUrl + link,
          title,
          image: img ? this.baseUrl + img : '',
          subtitle: ''
        })
      }
    })

    return results
  }

  async getMangaDetails(mangaId) {
    const res = await this.request(mangaId)
    const $ = cheerio.load(res.data)

    const title = $('title').text()
    const image = $('img').first().attr('src')

    return {
      id: mangaId,
      title,
      image: image ? this.baseUrl + image : '',
      desc: '',
      status: 1
    }
  }

  async getChapters(mangaId) {
    const res = await this.request(mangaId)
    const $ = cheerio.load(res.data)

    const chapters = []

    $('a').each((i, el) => {
      const link = $(el).attr('href')
      const title = $(el).text().trim()

      if (link && link.includes('/reader/')) {
        chapters.push({
          id: this.baseUrl + link,
          title,
          chapNum: i
        })
      }
    })

    return chapters.reverse()
  }

  async getChapterDetails(chapterId) {
    const res = await this.request(chapterId)
    const html = res.data

    let pages = []

    const jsonMatch = html.match(/images\s*:\s*(\[[^\]]+\])/)

    if (jsonMatch) {
      try {
        const images = JSON.parse(jsonMatch[1])
        pages = images.map(url => ({ image: url }))
      } catch (e) {}
    }

    if (pages.length === 0) {
      const matches = html.match(/https?:\/\/[^"]+\.(jpg|png|webp)/g)
      pages = (matches || []).map(url => ({ image: url }))
    }

    return {
      id: chapterId,
      pages
    }
  }
}

module.exports = Harpi
