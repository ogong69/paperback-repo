import { Source, MangaStatus } from "paperback-extensions-common"

export default class Harpi extends Source {

  constructor() {
    super({
      id: 'harpi-pro',
      name: 'Harpi Pro',
      baseUrl: 'https://harpi.in',
      lang: 'ko'
    })
  }

  async getHomePageSections() {
    const request = createRequestObject({
      url: this.baseUrl,
      method: 'GET'
    })

    const response = await this.requestManager.schedule(request, 1)
    const data = response.data

    const matches = data.match(/\/comic\/[^"]+/g) || []

    const items = matches.slice(0, 30).map((link, i) =>
      createMangaTile({
        id: this.baseUrl + link,
        image: '',
        title: createIconText({ text: `작품 ${i}` })
      })
    )

    return [createHomeSection({
      id: 'latest',
      title: '🔥 최신',
      items
    })]
  }

  async getSearchResults(query) {
    const request = createRequestObject({
      url: `${this.baseUrl}/search?q=${encodeURIComponent(query.title)}`,
      method: 'GET'
    })

    const response = await this.requestManager.schedule(request, 1)
    const data = response.data

    const matches = data.match(/\/comic\/[^"]+/g) || []

    return matches.map((link, i) =>
      createMangaTile({
        id: this.baseUrl + link,
        image: '',
        title: createIconText({ text: `검색 ${i}` })
      })
    )
  }

  async getMangaDetails(mangaId) {
    return createManga({
      id: mangaId,
      titles: [mangaId],
      image: '',
      desc: 'Harpi 작품',
      status: MangaStatus.ONGOING
    })
  }

  async getChapters(mangaId) {
    const request = createRequestObject({
      url: mangaId,
      method: 'GET'
    })

    const response = await this.requestManager.schedule(request, 1)
    const data = response.data

    const matches = data.match(/\/reader\/[^"]+/g) || []

    return matches.map((link, i) =>
      createChapter({
        id: this.baseUrl + link,
        mangaId: mangaId,
        name: `Chapter ${i}`,
        chapNum: i
      })
    ).reverse()
  }

  async getChapterDetails(mangaId, chapterId) {
    const request = createRequestObject({
      url: chapterId,
      method: 'GET'
    })

    const response = await this.requestManager.schedule(request, 1)
    const data = response.data

    const matches = data.match(/https?:\/\/[^"]+\.(jpg|png|webp)/g)

    return createChapterDetails({
      id: chapterId,
      mangaId: mangaId,
      pages: matches || []
    })
  }
}